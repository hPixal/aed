#define USECHRONO
#include "eval.hpp"
#include <cassert>
#include <climits>
#include <cstdlib>
#include <stack>
#include <map>

using namespace aed;
using namespace std;

bool isBST(btree<int>&T){
  // COMPLETAR...
  return false;
}

void fillBST(btree<int>&T,list<int>&L){
  // COMPLETAR...
}


bool eqsumsplit(set<int> &S) {
  // COMPLETAR...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main() {
  Eval ev;
  int vrbs = 0;
  int seed = 123;
  int h1=0,h2=0,h3=0;

  do {
    ev.eval<1>(isBST,vrbs);
    h1 = ev.evalr<1>(isBST,seed,vrbs);
    
    ev.eval<2>(fillBST,vrbs);
    h2 = ev.evalr<2>(fillBST,seed,vrbs);
    
    ev.eval<3>(eqsumsplit,vrbs);
    h3 = ev.evalr<3>(eqsumsplit,seed,vrbs);
    
    printf("S=%03d -> H1=%03d H2=%03d H3=%03d\n",
           seed,h1,h2,h3);
    
    printf("\n\nIngrese un valor para la semilla:");
  } while (cin>>seed);
  
  return 0;
}
