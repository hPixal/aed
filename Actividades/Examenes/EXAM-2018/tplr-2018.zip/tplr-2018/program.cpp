#define USECHRONO
#undef HAVE_MPI
#include "eval.hpp"
#include <cassert>
#include <climits>
#include <cstdlib>
#include <stack>
#include <map>

using namespace aed;
using namespace std;

bool tree_less(tree<int> &T1,tree<int> &T2) {
  //COMPLETAR
  return false;
}


//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void xcommon(list<int> &L1,list<int> &L2,list<int> &Lcommon) {
  //COMPLETAR
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void xsubtrees(btree<int> &T, int depth,
               list< btree<int> > &subtrees) {
  //COMPLETAR
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int maxsubk(set<int> S, int k){
  //COMPLETAR
  return 0;
}
//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>

int num_path(map<int,set<int>>& G, int i, int j){
  //COMPLETAR
  return 0;
}


//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>

bool super_stable_partition(list<int> &L, 
                            list<int> &L_low, list<int> &L_geq)
{
  //COMPLETAR
  return false;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main() {
  Eval ev;
  int vrbs = 0;
  int seed = 123;
  int h1=0,h2=0,h3=0,h4=0,h5=0,h6=0;

  do {

    ev.eval<1>(tree_less,vrbs);
    h1 = ev.evalr<1>(tree_less,seed,vrbs);

    ev.eval<2>(xcommon,vrbs);
    h2 = ev.evalr<2>(xcommon,seed,vrbs);

    ev.eval<3>(xsubtrees,vrbs);
    h3 = ev.evalr<3>(xsubtrees,seed,vrbs);

    ev.eval<4>(maxsubk,vrbs);
    h4 = ev.evalr<4>(maxsubk,seed,vrbs);
   
    ev.eval<5>(num_path,vrbs);
    h5 = ev.evalr<5>(num_path,seed,vrbs);
    
    ev.eval<6>(super_stable_partition,vrbs);
    h6 = ev.evalr<6>(super_stable_partition,seed,vrbs);
    
    printf("S=%03d -> H1=%03d H2=%03d H3=%03d H4=%03d H5=%03d H6=%03d\n",
           seed,h1,h2,h3,h4,h5,h6);
    
    printf("\n\nIngrese un valor para la semilla:");
  } while (cin>>seed);

  return 0;
}
