#define USECHRONO
#include <cassert>
#include <climits>
#include <cstdlib>
#include <stack>
#include <map>
#include <numeric>
#include "eval.hpp"

using namespace aed;
using namespace std;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*> sum_sublist (tpl 1)

list<int> sum_sublist(list<int>& L, int S) {
  return {};
}


//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*> discrete_moving_mean (tpl 1)

list<int> discrete_moving_mean(list<int>& L, int w){
  return {};
}


//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*> d10s (tpl 2)

list<int> d10s(tree<int> &T){
  return {};
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*> is_cycle (tpl 2)

bool is_cycle(graph_t &G) {
  return false;
}


//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*> existe_subc (tpl 3)

bool existe_subc(set<int> &S, int n) {
  return false;
}


//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*> replace_btree (tpl 3)

void replace_btree(btree<int>&T,bt_fun_t f){
  return;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main() {
  
  Eval ev;
  int vrbs = 0;
  int seed = 123;
  int h1=-1,h2=-1,h3=-1,h4=-1,h5=-1,h6=-1;
  
  do {
//    ev.eval<1>(sum_sublist,vrbs);
//    h1 = ev.evalr<1>(sum_sublist,seed,vrbs);
    
//    ev.eval<2>(discrete_moving_mean,vrbs);
//    h2 = ev.evalr<2>(discrete_moving_mean,seed,vrbs);
    
//    ev.eval<3>(d10s,vrbs);
//    h3 = ev.evalr<3>(d10s,seed,vrbs);
    
//    ev.eval<4>(is_cycle,vrbs);
//    h4 = ev.evalr<4>(is_cycle,seed,vrbs);
    
//    ev.eval<5>(existe_subc,vrbs);
//    h5 = ev.evalr<5>(existe_subc,seed,vrbs);
    
//    ev.eval<6>(replace_btree,vrbs);
//    h6 = ev.evalr<6>(replace_btree,seed,vrbs);
    
    printf("S=%03d  ->  H1=%03d H2=%03d  H3=%03d H4=%03d  H5=%03d H6=%03d\n",
           seed,h1,h2,h3,h4,h5,h6);
    
    printf("\n\nIngrese un valor para la semilla:");
  } while (cin>>seed);
  
  return 0;
}
